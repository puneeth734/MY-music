"""
SoundChain Music Player — Flask Backend
MCA 2nd Sem DSA Project
"""

from flask import Flask, request, jsonify, render_template, send_from_directory, session
from flask_cors import CORS
from werkzeug.security import generate_password_hash, check_password_hash
import pymysql
from pymysql.cursors import DictCursor
import os
import uuid
import datetime

app = Flask(__name__)
# Enable credentials (cookies) in CORS for frontend
CORS(app, supports_credentials=True)

# ── Config ──────────────────────────────────────────────────────────
BASE_DIR     = os.path.dirname(os.path.abspath(__file__))
UPLOAD_FOLDER = os.path.join(BASE_DIR, 'static', 'uploads')
ALLOWED_EXT  = {'mp3', 'wav', 'ogg', 'm4a', 'flac', 'aac'}
app.secret_key = 'soundchain_super_secret_key'  # Required for session

os.makedirs(UPLOAD_FOLDER, exist_ok=True)

# MySQL Credentials
MYSQL_HOST = 'localhost'
MYSQL_USER = 'root'
MYSQL_PASS = 'valgalli'
MYSQL_DB   = 'music_player'

# ── Database Setup ───────────────────────────────────────────────────
def get_connection(use_db=True):
    # If use_db is False, connects to MySQL server without selecting a database
    return pymysql.connect(
        host=MYSQL_HOST,
        user=MYSQL_USER,
        password=MYSQL_PASS,
        database=MYSQL_DB if use_db else None,
        cursorclass=DictCursor,
        autocommit=True
    )

def init_db():
    # 1. Create database if it doesn't exist
    try:
        conn = get_connection(use_db=False)
        with conn.cursor() as cursor:
            cursor.execute(f"CREATE DATABASE IF NOT EXISTS {MYSQL_DB}")
        conn.close()
    except Exception as e:
        print(f"Error creating database: {e}")

    # 2. Create tables in the database
    try:
        conn = get_connection(use_db=True)
        with conn.cursor() as cursor:
            # Users table
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS users (
                    id INTEGER PRIMARY KEY AUTO_INCREMENT,
                    email VARCHAR(255) UNIQUE NOT NULL,
                    password_hash VARCHAR(255) NOT NULL,
                    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
                )
            """)
            
            # Songs table with user_id foreign key
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS songs (
                    id INTEGER PRIMARY KEY AUTO_INCREMENT,
                    user_id INTEGER NOT NULL,
                    title VARCHAR(255) NOT NULL,
                    artist VARCHAR(255) DEFAULT '',
                    genre VARCHAR(255) DEFAULT '',
                    file_path VARCHAR(255) DEFAULT '',
                    is_favorite TINYINT(1) DEFAULT 0,
                    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
                )
            """)
        conn.close()
    except Exception as e:
        print(f"Error creating tables: {e}")

def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXT

# Format row for JSON
def format_song(row):
    if row and 'is_favorite' in row:
        row['is_favorite'] = bool(row['is_favorite'])
    return row

# ── Auth Routes ──────────────────────────────────────────────────────

@app.route('/api/register', methods=['POST'])
def register():
    data = request.get_json() or {}
    email = data.get('email', '').strip().lower()
    password = data.get('password', '')

    if not email or not password:
        return jsonify({'error': 'Email and password are required'}), 400

    conn = get_connection()
    with conn.cursor() as cursor:
        # Check if email exists
        cursor.execute("SELECT id FROM users WHERE email = %s", (email,))
        if cursor.fetchone():
            conn.close()
            return jsonify({'error': 'Email already registered'}), 400

        # Hash password and insert user
        pass_hash = generate_password_hash(password)
        cursor.execute(
            "INSERT INTO users (email, password_hash) VALUES (%s, %s)",
            (email, pass_hash)
        )
        user_id = cursor.lastrowid
    conn.close()
    
    session['user_id'] = user_id
    session['email'] = email
    return jsonify({'message': 'Registered successfully', 'user': {'id': user_id, 'email': email}}), 201

@app.route('/api/login', methods=['POST'])
def login():
    data = request.get_json() or {}
    email = data.get('email', '').strip().lower()
    password = data.get('password', '')

    if not email or not password:
        return jsonify({'error': 'Email and password are required'}), 400

    conn = get_connection()
    with conn.cursor() as cursor:
        cursor.execute("SELECT * FROM users WHERE email = %s", (email,))
        user = cursor.fetchone()
    conn.close()

    if user and check_password_hash(user['password_hash'], password):
        session['user_id'] = user['id']
        session['email'] = user['email']
        return jsonify({'message': 'Logged in successfully', 'user': {'id': user['id'], 'email': user['email']}})
    
    return jsonify({'error': 'Invalid credentials'}), 401

@app.route('/api/logout', methods=['POST'])
def logout():
    session.clear()
    return jsonify({'message': 'Logged out successfully'})

@app.route('/api/me', methods=['GET'])
def me():
    if 'user_id' in session:
        return jsonify({'user': {'id': session['user_id'], 'email': session.get('email')}})
    return jsonify({'user': None})

# Decorator to enforce login on song routes
def login_required(f):
    def wrap(*args, **kwargs):
        if 'user_id' not in session:
            return jsonify({'error': 'Unauthorized'}), 401
        return f(*args, **kwargs)
    wrap.__name__ = f.__name__
    return wrap

# ── Routes ───────────────────────────────────────────────────────────

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/uploads/<path:filename>')
def uploaded_file(filename):
    return send_from_directory(UPLOAD_FOLDER, filename)


# GET  /api/songs  — fetch all songs for logged-in user
@app.route('/api/songs', methods=['GET'])
@login_required
def get_songs():
    conn = get_connection()
    with conn.cursor() as cursor:
        cursor.execute("SELECT * FROM songs WHERE user_id = %s ORDER BY id ASC", (session['user_id'],))
        rows = cursor.fetchall()
    conn.close()
    return jsonify([format_song(r) for r in rows])


# POST /api/songs  — add new song
@app.route('/api/songs', methods=['POST'])
@login_required
def add_song():
    title  = request.form.get('title', '').strip()
    artist = request.form.get('artist', '').strip()
    genre  = request.form.get('genre', '').strip()
    file   = request.files.get('file')

    if not title:
        return jsonify({'error': 'Title is required'}), 400

    file_path = ''
    if file and file.filename and allowed_file(file.filename):
        ext       = file.filename.rsplit('.', 1)[1].lower()
        safe_name = f"{uuid.uuid4().hex}.{ext}"
        file.save(os.path.join(UPLOAD_FOLDER, safe_name))
        file_path = safe_name
    elif file and file.filename:
        return jsonify({'error': 'File type not allowed'}), 400

    conn = get_connection()
    with conn.cursor() as cursor:
        cursor.execute(
            "INSERT INTO songs (user_id, title, artist, genre, file_path) VALUES (%s, %s, %s, %s, %s)",
            (session['user_id'], title, artist, genre, file_path)
        )
        song_id = cursor.lastrowid
        cursor.execute("SELECT * FROM songs WHERE id = %s", (song_id,))
        row = cursor.fetchone()
    conn.close()
    return jsonify(format_song(row)), 201


# PUT /api/songs/<id>  — update song details
@app.route('/api/songs/<int:song_id>', methods=['PUT'])
@login_required
def update_song(song_id):
    data   = request.get_json() or {}
    title  = data.get('title', '').strip()
    artist = data.get('artist', '').strip()
    genre  = data.get('genre', '').strip()

    if not title:
        return jsonify({'error': 'Title is required'}), 400

    conn = get_connection()
    with conn.cursor() as cursor:
        cursor.execute(
            "UPDATE songs SET title=%s, artist=%s, genre=%s WHERE id=%s AND user_id=%s",
            (title, artist, genre, song_id, session['user_id'])
        )
        cursor.execute("SELECT * FROM songs WHERE id=%s AND user_id=%s", (song_id, session['user_id']))
        row = cursor.fetchone()
    conn.close()

    if not row:
        return jsonify({'error': 'Song not found or unauthorized'}), 404
    return jsonify(format_song(row))


# PATCH /api/songs/<id>/favorite  — toggle favorite
@app.route('/api/songs/<int:song_id>/favorite', methods=['PATCH'])
@login_required
def toggle_favorite(song_id):
    data       = request.get_json() or {}
    is_favorite = 1 if data.get('is_favorite', False) else 0

    conn = get_connection()
    with conn.cursor() as cursor:
        cursor.execute(
            "UPDATE songs SET is_favorite=%s WHERE id=%s AND user_id=%s",
            (is_favorite, song_id, session['user_id'])
        )
        cursor.execute("SELECT * FROM songs WHERE id=%s AND user_id=%s", (song_id, session['user_id']))
        row = cursor.fetchone()
    conn.close()

    if not row:
        return jsonify({'error': 'Song not found or unauthorized'}), 404
    return jsonify(format_song(row))


# DELETE /api/songs/<id>  — delete song
@app.route('/api/songs/<int:song_id>', methods=['DELETE'])
@login_required
def delete_song(song_id):
    conn = get_connection()
    with conn.cursor() as cursor:
        cursor.execute("SELECT file_path FROM songs WHERE id=%s AND user_id=%s", (song_id, session['user_id']))
        row = cursor.fetchone()
        
        if not row:
            conn.close()
            return jsonify({'error': 'Song not found or unauthorized'}), 404

        # Remove audio file from disk
        if row.get('file_path'):
            fp = os.path.join(UPLOAD_FOLDER, row['file_path'])
            if os.path.exists(fp):
                os.remove(fp)

        cursor.execute("DELETE FROM songs WHERE id=%s AND user_id=%s", (song_id, session['user_id']))
    conn.close()

    return jsonify({'message': 'Deleted successfully'})


# GET /api/songs/search?q=<query> — search songs
@app.route('/api/songs/search', methods=['GET'])
@login_required
def search_songs():
    q = request.args.get('q', '').strip()
    if not q:
        return jsonify([])

    conn = get_connection()
    with conn.cursor() as cursor:
        # Search title or artist for the specific user
        search_pattern = f'%{q}%'
        cursor.execute(
            "SELECT * FROM songs WHERE user_id = %s AND (title LIKE %s OR artist LIKE %s) ORDER BY id ASC",
            (session['user_id'], search_pattern, search_pattern)
        )
        rows = cursor.fetchall()
    conn.close()
    return jsonify([format_song(r) for r in rows])


# GET /api/favorites — get all favorite songs
@app.route('/api/favorites', methods=['GET'])
@login_required
def get_favorites():
    conn = get_connection()
    with conn.cursor() as cursor:
        cursor.execute(
            "SELECT * FROM songs WHERE user_id = %s AND is_favorite=1 ORDER BY id ASC",
            (session['user_id'],)
        )
        rows = cursor.fetchall()
    conn.close()
    return jsonify([format_song(r) for r in rows])


# ── Run ──────────────────────────────────────────────────────────────
if __name__ == '__main__':
    init_db()
    print("🎵 SoundChain server starting at http://localhost:5000")
    app.run(debug=True, host='0.0.0.0', port=5000)
