# 🎵 SoundChain — DSA Music Player
**MCA 2nd Semester | Data Structures Project**  
*Doubly Linked List based Music Player*

---

## Project Structure

```
music-player/
├── app.py                  ← Flask backend (Python)
├── requirements.txt        ← Python dependencies
├── music.db                ← SQLite database (auto-created)
├── templates/
│   └── index.html          ← Main HTML page
└── static/
    ├── css/
    │   └── style.css       ← All styles
    ├── js/
    │   ├── dll.js          ← Doubly Linked List class (core DSA)
    │   └── app.js          ← App logic (CRUD, playback, search)
    └── uploads/            ← Uploaded audio files stored here
```

---

## Setup & Run

### 1. Install Python dependencies
```bash
cd music-player
pip install -r requirements.txt
```

### 2. Run the server
```bash
python app.py
```

### 3. Open in browser
```
http://localhost:5000
```

---

## Features

| Feature | Description |
|---|---|
| **DLL Visualization** | Now Playing card shows prev/next nodes like a real DLL |
| **Swipe / Scroll** | Scroll or swipe to move through linked list nodes |
| **Add Song** | Upload audio file from file manager |
| **Delete Song** | Red button removes from list + database |
| **Update Song** | Blue button edits title, artist, genre |
| **Search** | Search by song name or artist, click to play |
| **Favorites** | Heart a song to add to Favorites page |
| **Persistent** | All data saved in SQLite via Python Flask |

---

## API Endpoints

| Method | Endpoint | Description |
|---|---|---|
| GET | `/api/songs` | Get all songs |
| POST | `/api/songs` | Add new song (multipart form) |
| PUT | `/api/songs/<id>` | Update song details |
| PATCH | `/api/songs/<id>/favorite` | Toggle favorite |
| DELETE | `/api/songs/<id>` | Delete song |
| GET | `/api/songs/search?q=` | Search songs |
| GET | `/api/favorites` | Get favorite songs |

---

## DSA — Doubly Linked List

The DLL is implemented in `static/js/dll.js`:

- **SongNode** → Each node holds song data + `prev` and `next` pointers
- **append(song)** → Add to end of list — O(1)
- **deleteById(id)** → Remove node, re-link neighbors — O(n)
- **updateById(id, data)** → Update node data — O(n)
- **moveNext() / movePrev()** → Navigate list — O(1)
- **search(query)** → Linear search by title/artist — O(n)

---

*Built with Flask + SQLite + Vanilla JS*
