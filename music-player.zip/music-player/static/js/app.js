// ===== SOUNDCHAIN — APP.JS =====
const API = '/api';
const audio = document.getElementById('audio-player');
let isPlaying = false;
let pendingFile = null;
let currentUser = null;
let isRegisterMode = false;

// ==================== INIT ====================
async function checkAuth() {
  try {
    const res = await fetch(`${API}/me`);
    const data = await res.json();
    return data.user;
  } catch {
    return null;
  }
}

async function initApp() {
  currentUser = await checkAuth();
  
  if (currentUser) {
    document.getElementById('nav-links-container').style.display = 'flex';
    document.getElementById('page-auth').classList.remove('active');
    document.getElementById('page-home').classList.add('active');
    await loadData();
    setupSwipe();
  } else {
    document.getElementById('nav-links-container').style.display = 'none';
    document.querySelectorAll('.page').forEach(p => p.classList.remove('active'));
    document.getElementById('page-auth').classList.add('active');
  }
}

async function loadData() {
  try {
    const res = await fetch(`${API}/songs`);
    if (!res.ok) throw new Error();
    const songs = await res.json();
    dll.clear();
    songs.forEach(s => dll.append(s));
    renderCurrentSong();
    renderPlaylist();
    renderFavorites();
  } catch (e) {
    showToast('Could not load songs', 'error');
  }
}

// ==================== AUTH ====================
function toggleAuthMode() {
  isRegisterMode = !isRegisterMode;
  document.getElementById('auth-title').textContent = isRegisterMode ? 'Create Account' : 'Welcome Back';
  document.getElementById('auth-subtitle').textContent = isRegisterMode ? 'Sign up to start your music library' : 'Login to access your music library';
  document.getElementById('auth-submit-btn').textContent = isRegisterMode ? 'Register' : 'Login';
  document.getElementById('auth-switch-text').textContent = isRegisterMode ? 'Already have an account?' : 'Don\'t have an account?';
  document.querySelector('.auth-switch-btn').textContent = isRegisterMode ? 'Login' : 'Register';
}

async function handleAuth(e) {
  e.preventDefault();
  const email = document.getElementById('auth-email').value;
  const password = document.getElementById('auth-password').value;
  
  const endpoint = isRegisterMode ? `${API}/register` : `${API}/login`;
  
  try {
    const res = await fetch(endpoint, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ email, password })
    });
    const data = await res.json();
    
    if (!res.ok) throw new Error(data.error || 'Authentication failed');
    
    showToast(data.message, 'success');
    document.getElementById('auth-password').value = '';
    initApp();
  } catch (err) {
    showToast(err.message, 'error');
  }
}

async function logout() {
  try {
    await fetch(`${API}/logout`, { method: 'POST' });
    stopAndReset();
    dll.clear();
    initApp();
    showToast('Logged out', 'success');
  } catch {
    showToast('Error logging out', 'error');
  }
}

// ==================== NAV ====================
function showPage(name) {
  document.querySelectorAll('.page').forEach(p => p.classList.remove('active'));
  document.querySelectorAll('.nav-btn:not(#logout-btn)').forEach(b => b.classList.remove('active'));
  document.getElementById(`page-${name}`).classList.add('active');
  const navBtn = document.querySelector(`[onclick="showPage('${name}')"]`);
  if(navBtn) navBtn.classList.add('active');
  if (name === 'playlist') renderPlaylist();
  if (name === 'favorites') renderFavorites();
}

// ==================== RENDER NOW PLAYING ====================
function renderCurrentSong(animate = false) {
  const card = document.getElementById('now-playing-card');
  const node = dll.current;

  if (animate) {
    card.classList.add('switching');
    setTimeout(() => card.classList.remove('switching'), 350);
  }

  if (!node) {
    document.getElementById('np-title').textContent = 'No song loaded';
    document.getElementById('np-artist').textContent = '— Add songs to begin —';
    document.getElementById('np-genre').textContent = '';
    document.getElementById('dll-index').textContent = '0';
    document.getElementById('dll-total').textContent = '0';
    document.getElementById('ghost-prev-title').textContent = '— head —';
    document.getElementById('ghost-prev-artist').textContent = '';
    document.getElementById('ghost-next-title').textContent = '— tail —';
    document.getElementById('ghost-next-artist').textContent = '';
    return;
  }

  const { title, artist, genre } = node.song;
  document.getElementById('np-title').textContent = title || 'Untitled';
  document.getElementById('np-artist').textContent = artist || 'Unknown Artist';
  document.getElementById('np-genre').textContent = genre || '';
  document.getElementById('np-genre-wrap').style.display = genre ? 'block' : 'none';
  document.getElementById('dll-index').textContent = dll.currentIndex();
  document.getElementById('dll-total').textContent = dll.size;

  // Ghost prev
  if (node.prev) {
    document.getElementById('ghost-prev-title').textContent = node.prev.song.title;
    document.getElementById('ghost-prev-artist').textContent = node.prev.song.artist || '';
    document.getElementById('ghost-prev').style.opacity = '';
  } else {
    document.getElementById('ghost-prev-title').textContent = '— head —';
    document.getElementById('ghost-prev-artist').textContent = 'start of list';
    document.getElementById('ghost-prev').style.opacity = '0.2';
  }

  // Ghost next
  if (node.next) {
    document.getElementById('ghost-next-title').textContent = node.next.song.title;
    document.getElementById('ghost-next-artist').textContent = node.next.song.artist || '';
    document.getElementById('ghost-next').style.opacity = '';
  } else {
    document.getElementById('ghost-next-title').textContent = '— tail —';
    document.getElementById('ghost-next-artist').textContent = 'end of list';
    document.getElementById('ghost-next').style.opacity = '0.2';
  }

  // Fav button
  const favBtn = document.getElementById('fav-btn');
  if (node.song.is_favorite) {
    favBtn.textContent = '♥'; favBtn.classList.add('faved');
  } else {
    favBtn.textContent = '♡'; favBtn.classList.remove('faved');
  }

  // Load audio
  if (node.song.file_path) {
    audio.src = `/uploads/${node.song.file_path}`;
    resetProgress();
  }
}

// ==================== PLAYBACK ====================
function togglePlay() {
  if (!dll.current || !dll.current.song.file_path) {
    showToast('No audio file for this song', 'error'); return;
  }
  if (isPlaying) {
    audio.pause(); isPlaying = false;
    document.getElementById('play-btn').textContent = '▶';
    document.getElementById('now-playing-card').classList.remove('playing');
  } else {
    audio.play().catch(() => showToast('Could not play audio', 'error'));
    isPlaying = true;
    document.getElementById('play-btn').textContent = '⏸';
    document.getElementById('now-playing-card').classList.add('playing');
  }
}

function nextSong() {
  const moved = dll.moveNext();
  if (moved) {
    stopAndReset(); renderCurrentSong(true);
    if (isPlaying) { isPlaying = false; setTimeout(togglePlay, 200); }
    showToast(`▶  ${moved.song.title}`);
  } else { showToast('Already at last song', 'error'); }
}

function prevSong() {
  const moved = dll.movePrev();
  if (moved) {
    stopAndReset(); renderCurrentSong(true);
    if (isPlaying) { isPlaying = false; setTimeout(togglePlay, 200); }
    showToast(`◀  ${moved.song.title}`);
  } else { showToast('Already at first song', 'error'); }
}

function stopAndReset() {
  audio.pause(); audio.currentTime = 0; isPlaying = false;
  document.getElementById('play-btn').textContent = '▶';
  document.getElementById('now-playing-card').classList.remove('playing');
  resetProgress();
}

// ==================== PROGRESS ====================
audio.addEventListener('timeupdate', () => {
  if (!audio.duration) return;
  const pct = (audio.currentTime / audio.duration) * 100;
  document.getElementById('progress-fill').style.width = pct + '%';
  document.getElementById('progress-thumb').style.left = pct + '%';
  document.getElementById('time-current').textContent = formatTime(audio.currentTime);
});
audio.addEventListener('loadedmetadata', () => {
  document.getElementById('time-total').textContent = formatTime(audio.duration);
});
audio.addEventListener('ended', nextSong);

function seekAudio(e) {
  if (!audio.duration) return;
  const bar = document.getElementById('progress-bar');
  const rect = bar.getBoundingClientRect();
  const pct = Math.max(0, Math.min(1, (e.clientX - rect.left) / rect.width));
  audio.currentTime = pct * audio.duration;
}
function resetProgress() {
  document.getElementById('progress-fill').style.width = '0%';
  document.getElementById('progress-thumb').style.left = '0%';
  document.getElementById('time-current').textContent = '0:00';
  document.getElementById('time-total').textContent = '0:00';
}
function formatTime(s) {
  if (!s || isNaN(s)) return '0:00';
  return `${Math.floor(s/60)}:${Math.floor(s%60).toString().padStart(2,'0')}`;
}
function setVolume(val) { audio.volume = val; }

// ==================== FAVORITE ====================
async function toggleFavorite() {
  if (!dll.current) return;
  const song = dll.current.song;
  const newFav = !song.is_favorite;
  try {
    const res = await fetch(`${API}/songs/${song.id}/favorite`, {
      method: 'PATCH', headers: {'Content-Type':'application/json'},
      body: JSON.stringify({ is_favorite: newFav })
    });
    if (!res.ok) throw new Error();
    dll.updateById(song.id, { is_favorite: newFav });
    renderCurrentSong(); renderFavorites();
    showToast(newFav ? '♥  Added to Favorites' : '♡  Removed from Favorites', newFav ? 'success' : '');
  } catch { showToast('Failed to update favorite', 'error'); }
}

// ==================== ADD SONG ====================
function openAddModal() {
  ['add-title','add-artist','add-genre'].forEach(id => document.getElementById(id).value = '');
  document.getElementById('add-file').value = '';
  document.getElementById('file-label').textContent = 'Click to choose audio file (.mp3 .wav .ogg)';
  pendingFile = null;
  document.getElementById('add-modal').classList.add('open');
}
function closeAddModal() { document.getElementById('add-modal').classList.remove('open'); }
function closeModalOutside(e) { if (e.target.id === 'add-modal') closeAddModal(); }

function fileChosen(input) {
  if (input.files[0]) {
    pendingFile = input.files[0];
    document.getElementById('file-label').textContent = '🎵  ' + pendingFile.name;
  }
}

async function addSong() {
  const title = document.getElementById('add-title').value.trim();
  const artist = document.getElementById('add-artist').value.trim();
  const genre = document.getElementById('add-genre').value.trim();
  if (!title) { showToast('Please enter a song title', 'error'); return; }
  if (!pendingFile) { showToast('Please choose an audio file', 'error'); return; }

  const formData = new FormData();
  formData.append('title', title);
  formData.append('artist', artist);
  formData.append('genre', genre);
  formData.append('file', pendingFile);

  try {
    const res = await fetch(`${API}/songs`, { method: 'POST', body: formData });
    if (!res.ok) throw new Error();
    const song = await res.json();
    dll.append(song);
    if (dll.size === 1) renderCurrentSong();
    else renderCurrentSong(); // refresh ghost nodes
    renderPlaylist();
    closeAddModal();
    showToast('✓  Song added to playlist!', 'success');
  } catch { showToast('Failed to add song', 'error'); }
}

// ==================== EDIT ====================
function openEditModal(id) {
  const node = dll.findAndSetCurrent(id);
  if (!node) return;
  const s = node.song;
  document.getElementById('edit-id').value = s.id;
  document.getElementById('edit-title').value = s.title;
  document.getElementById('edit-artist').value = s.artist || '';
  document.getElementById('edit-genre').value = s.genre || '';
  document.getElementById('edit-modal').classList.add('open');
}
function closeEditModal() { document.getElementById('edit-modal').classList.remove('open'); }
function closeEditModalOutside(e) { if (e.target.id === 'edit-modal') closeEditModal(); }

async function saveEdit() {
  const id = parseInt(document.getElementById('edit-id').value);
  const title = document.getElementById('edit-title').value.trim();
  const artist = document.getElementById('edit-artist').value.trim();
  const genre = document.getElementById('edit-genre').value.trim();
  if (!title) { showToast('Title cannot be empty', 'error'); return; }
  try {
    const res = await fetch(`${API}/songs/${id}`, {
      method: 'PUT', headers: {'Content-Type':'application/json'},
      body: JSON.stringify({ title, artist, genre })
    });
    if (!res.ok) throw new Error();
    dll.updateById(id, { title, artist, genre });
    renderCurrentSong(); renderPlaylist(); renderFavorites();
    closeEditModal();
    showToast('✓  Song updated!', 'success');
  } catch { showToast('Failed to update song', 'error'); }
}

// ==================== DELETE ====================
async function deleteSong(id) {
  if (!confirm('Delete this song from your playlist?')) return;
  try {
    const res = await fetch(`${API}/songs/${id}`, { method: 'DELETE' });
    if (!res.ok) throw new Error();
    dll.deleteById(id);
    renderCurrentSong(); renderPlaylist(); renderFavorites();
    showToast('Song deleted', '');
  } catch { showToast('Failed to delete song', 'error'); }
}

// ==================== PLAY FROM LIST ====================
function playSongById(id) {
  const node = dll.findAndSetCurrent(id);
  if (node) {
    stopAndReset(); renderCurrentSong(true);
    showPage('home');
    setTimeout(() => { isPlaying = false; togglePlay(); }, 250);
  }
}

// ==================== RENDER LISTS ====================
function renderPlaylist() {
  const container = document.getElementById('playlist-container');
  const songs = dll.toArray();
  document.getElementById('playlist-count').textContent = `${songs.length} song${songs.length !== 1 ? 's' : ''}`;
  if (!songs.length) {
    container.innerHTML = '<div class="empty-state">No songs yet. Add some from Home!</div>'; return;
  }
  container.innerHTML = songs.map((s, i) => `
    <div class="song-card ${dll.current && dll.current.song.id === s.id ? 'active-song' : ''}"
         style="animation-delay:${i * 0.05}s" onclick="playSongById(${s.id})">
      <span class="sc-index mono">${String(i+1).padStart(2,'0')}</span>
      <span class="sc-icon">${s.is_favorite ? '♥' : '♪'}</span>
      <div class="sc-info">
        <div class="sc-title">${s.title}${s.is_favorite ? ' <span class="sc-fav">♥</span>' : ''}</div>
        <div class="sc-meta">${s.artist || 'Unknown Artist'}${s.genre ? ' · ' + s.genre : ''}</div>
      </div>
      <div class="sc-actions" onclick="event.stopPropagation()">
        <button class="btn-edit" onclick="openEditModal(${s.id})">Edit</button>
        <button class="btn-delete" onclick="deleteSong(${s.id})">Delete</button>
      </div>
    </div>`).join('');
}

function renderFavorites() {
  const container = document.getElementById('favorites-container');
  const favs = dll.getFavorites();
  document.getElementById('fav-count').textContent = `${favs.length} song${favs.length !== 1 ? 's' : ''}`;
  if (!favs.length) {
    container.innerHTML = '<div class="empty-state">No favorites yet. Heart a song to add it here!</div>'; return;
  }
  container.innerHTML = favs.map((s, i) => `
    <div class="song-card" style="animation-delay:${i * 0.05}s" onclick="playSongById(${s.id})">
      <span class="sc-index mono">${String(i+1).padStart(2,'0')}</span>
      <span class="sc-icon" style="color:var(--red)">♥</span>
      <div class="sc-info">
        <div class="sc-title">${s.title}</div>
        <div class="sc-meta">${s.artist || 'Unknown Artist'}${s.genre ? ' · ' + s.genre : ''}</div>
      </div>
      <div class="sc-actions" onclick="event.stopPropagation()">
        <button class="btn-edit" onclick="openEditModal(${s.id})">Edit</button>
        <button class="btn-delete" onclick="deleteSong(${s.id})">Delete</button>
      </div>
    </div>`).join('');
}

// ==================== SEARCH ====================
function searchSongs(query) {
  const container = document.getElementById('search-results');
  if (!query.trim()) { container.classList.remove('visible'); container.innerHTML = ''; return; }
  const results = dll.search(query);
  if (!results.length) {
    container.innerHTML = '<div class="empty-state" style="padding:1.25rem;font-size:0.9rem">No songs found</div>';
    container.classList.add('visible'); return;
  }
  container.innerHTML = results.map(s => `
    <div class="search-result-item" onclick="playSongById(${s.id})">
      <span class="sri-icon">♪</span>
      <div class="sri-info">
        <div class="sri-title">${s.title}</div>
        <div class="sri-artist">${s.artist || 'Unknown Artist'}</div>
      </div>
      <span class="sri-play mono">▶ play</span>
    </div>`).join('');
  container.classList.add('visible');
}

function clearSearch() {
  document.getElementById('search-input').value = '';
  document.getElementById('search-results').classList.remove('visible');
  document.getElementById('search-results').innerHTML = '';
}

// ==================== SWIPE ====================
function setupSwipe() {
  const wrapper = document.querySelector('.dll-track-wrapper');
  if(!wrapper) return;
  let startX = 0;
  wrapper.addEventListener('touchstart', e => { startX = e.touches[0].clientX; }, { passive: true });
  wrapper.addEventListener('touchend', e => {
    const dx = e.changedTouches[0].clientX - startX;
    if (Math.abs(dx) > 50) { dx < 0 ? nextSong() : prevSong(); }
  });
  wrapper.addEventListener('wheel', e => {
    e.preventDefault();
    if (e.deltaX > 30 || e.deltaY > 30) nextSong();
    else if (e.deltaX < -30 || e.deltaY < -30) prevSong();
  }, { passive: false });
}

// ==================== TOAST ====================
let toastTimer;
function showToast(msg, type = '') {
  const t = document.getElementById('toast');
  t.textContent = msg; t.className = `toast show ${type}`;
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => t.classList.remove('show'), 2800);
}

window.addEventListener('DOMContentLoaded', initApp);
