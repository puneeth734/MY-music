// ===== DOUBLY LINKED LIST IMPLEMENTATION =====

class SongNode {
  constructor(song) {
    this.song = song;   // { id, title, artist, genre, file_path, is_favorite }
    this.prev = null;
    this.next = null;
  }
}

class DoublyLinkedList {
  constructor() {
    this.head = null;
    this.tail = null;
    this.current = null;
    this.size = 0;
  }

  // Append a new song to the end of the list
  append(song) {
    const node = new SongNode(song);
    if (!this.head) {
      this.head = node;
      this.tail = node;
      this.current = node;
    } else {
      node.prev = this.tail;
      this.tail.next = node;
      this.tail = node;
    }
    this.size++;
    return node;
  }

  // Delete a node by song id
  deleteById(id) {
    let node = this.head;
    while (node) {
      if (node.song.id === id) {
        if (node.prev) node.prev.next = node.next;
        else this.head = node.next;

        if (node.next) node.next.prev = node.prev;
        else this.tail = node.prev;

        // Update current pointer
        if (this.current === node) {
          this.current = node.next || node.prev || null;
        }
        this.size--;
        return true;
      }
      node = node.next;
    }
    return false;
  }

  // Update song details by id
  updateById(id, updatedFields) {
    let node = this.head;
    while (node) {
      if (node.song.id === id) {
        node.song = { ...node.song, ...updatedFields };
        return node.song;
      }
      node = node.next;
    }
    return null;
  }

  // Move to next node
  moveNext() {
    if (this.current && this.current.next) {
      this.current = this.current.next;
      return this.current;
    }
    return null;
  }

  // Move to previous node
  movePrev() {
    if (this.current && this.current.prev) {
      this.current = this.current.prev;
      return this.current;
    }
    return null;
  }

  // Find node by id and set as current
  findAndSetCurrent(id) {
    let node = this.head;
    while (node) {
      if (node.song.id === id) {
        this.current = node;
        return node;
      }
      node = node.next;
    }
    return null;
  }

  // Search by title (case-insensitive)
  search(query) {
    const results = [];
    let node = this.head;
    const q = query.toLowerCase();
    while (node) {
      if (
        node.song.title.toLowerCase().includes(q) ||
        (node.song.artist && node.song.artist.toLowerCase().includes(q))
      ) {
        results.push(node.song);
      }
      node = node.next;
    }
    return results;
  }

  // Get all songs as array
  toArray() {
    const arr = [];
    let node = this.head;
    while (node) {
      arr.push(node.song);
      node = node.next;
    }
    return arr;
  }

  // Get current index (1-based)
  currentIndex() {
    if (!this.current) return 0;
    let idx = 1, node = this.head;
    while (node) {
      if (node === this.current) return idx;
      idx++;
      node = node.next;
    }
    return 0;
  }

  // Get favorites
  getFavorites() {
    return this.toArray().filter(s => s.is_favorite);
  }

  // Clear the list
  clear() {
    this.head = null;
    this.tail = null;
    this.current = null;
    this.size = 0;
  }
}

// Global DLL instance
const dll = new DoublyLinkedList();
